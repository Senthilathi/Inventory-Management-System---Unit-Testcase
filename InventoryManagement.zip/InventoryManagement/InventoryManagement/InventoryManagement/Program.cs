﻿using InventoryManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            OrderInvoker orderInvoker = new OrderInvoker();
            if (args != null && args.Length > 0)
            {
                foreach (var item in args)
                {
                    var cmdItem = GetExecutionCmd(item);
                    var option = (CommandOption)Enum.Parse(typeof(CommandOption), cmdItem[0]);

                    switch (option)
                    {
                        case CommandOption.create:
                            orderInvoker.ExecuteCommand(option, cmdItem[1], Convert.ToDouble(cmdItem[2]), Convert.ToDouble(cmdItem[3]));
                            break;
                        case CommandOption.updateBuy:
                            orderInvoker.ExecuteCommand(option, cmdItem[1], Convert.ToInt32(cmdItem[2]));
                            break;
                        case CommandOption.updateSell:
                            orderInvoker.ExecuteCommand(option, cmdItem[1], Convert.ToInt32(cmdItem[2]));
                            break;
                        case CommandOption.delete:
                            orderInvoker.ExecuteCommand(option, cmdItem[1]);
                            break;
                        case CommandOption.updateSellPrice:
                            orderInvoker.ExecuteCommand(option, cmdItem[1], Convert.ToDouble(cmdItem[2]));
                            break;
                        default: throw new ArgumentOutOfRangeException();
                            break;
                    }
                }
                orderInvoker.InventoryReport();
            }
            else
            {
                Console.Write("\t\t"); Console.WriteLine("Welcome to Inventory Management System !!!"); Console.WriteLine(); Console.WriteLine();
                

                orderInvoker.ExecuteCommand(CommandOption.create, "Book01", 10.50, 13.79);
                orderInvoker.ExecuteCommand(CommandOption.create, "Food01", 1.47, 3.98);
                orderInvoker.ExecuteCommand(CommandOption.create, "Med01", 30.63, 34.29);
                orderInvoker.ExecuteCommand(CommandOption.create, "Tab01", 57.00, 84.98);
                orderInvoker.ExecuteCommand(CommandOption.updateBuy, "Tab01", 100);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Tab01", 2);
                orderInvoker.ExecuteCommand(CommandOption.updateBuy, "Food01", 500);
                orderInvoker.ExecuteCommand(CommandOption.updateBuy, "Book01", 100);
                orderInvoker.ExecuteCommand(CommandOption.updateBuy, "Med01", 100);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Food01", 1);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Food01", 1);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Tab01", 2);
                orderInvoker.InventoryReport();
                orderInvoker.ExecuteCommand(CommandOption.delete, "Book01");
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Tab01", 5);
                orderInvoker.ExecuteCommand(CommandOption.create, "Mobi01", 10.51, 44.56);
                orderInvoker.ExecuteCommand(CommandOption.updateBuy, "Mobi01", 250);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Food01", 5);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Mobi01", 4);
                orderInvoker.ExecuteCommand(CommandOption.updateSell, "Med01", 10);
                orderInvoker.InventoryReport();
                //In-office Extension
                //orderInvoker.ExecuteCommand(CommandOption.UpdateSellPrice, "Food01", 3.50);
                //orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01", 10);
                //orderInvoker.InventoryReport();

                Console.ReadKey();
            }
        }

        private static string[] GetExecutionCmd(string cmd)
        {
            string[] exeCmd = cmd.Split(' ');
            return exeCmd;
        }
    }
}
