﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class Item
    {
        public string Name { get; set; }
        public double BuyingPrice { get; set; }
        public double SellingPrice { get; set; }
        public int AvailableQuantity { get; set; }
        public double Total { get { return this.BuyingPrice * this .AvailableQuantity ; }}
        public double ProfitAmount { get; set; }
        public bool IsDelete { get; set; }

        public Item(string name, double buyingPrice, double sellingPrice)
        {
            this.Name = name;
            this.BuyingPrice = buyingPrice;
            this.SellingPrice = sellingPrice;     
        }

        public Item(string name, int availableQuantity)
        {
            this.Name = name;
            this.AvailableQuantity = availableQuantity;            
        }

        public Item(string name)
        {
            this.Name = name;            
        }
        public Item(string name, double sellingPrice)
        {
            this.Name = name;
            this.SellingPrice = sellingPrice;
        }
        public void DisplayStockItem()
        {
            Console.Write(this.Name); Console.Write("\t\t");
            Console.Write(String.Format("{0:0.00}", this.BuyingPrice)); Console.Write("\t\t");
            Console.Write(String.Format("{0:0.00}", this.SellingPrice)); Console.Write("\t\t");
            Console.Write(this.AvailableQuantity); Console.Write("\t\t");
            Console.Write(String.Format("{0:0.00}", this.Total)); Console.Write("\t");
            Console.WriteLine();
        }
           
    }
}
