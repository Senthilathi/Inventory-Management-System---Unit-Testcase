﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class CommandFactory
    {
        public OrderCommand GetInstance(CommandOption commandOption)
        {
            switch (commandOption)
            {
                case CommandOption.create:
                    return new CreateOrder();
                    
                case CommandOption.updateBuy:
                    return new UpdateBuyOrder();

                case CommandOption.updateSell:
                    return new UpdateSellOrder();
                
                case CommandOption.delete:
                    return new DeleteOrder();

                case CommandOption.updateSellPrice:
                    return new UpdateSellingPrice();

                default: throw new ArgumentOutOfRangeException();                
            }
        }
    }
}
