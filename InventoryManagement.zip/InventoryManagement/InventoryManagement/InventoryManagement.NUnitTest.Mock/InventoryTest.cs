﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace InventoryManagement.TestProject
{
    [TestClass]
    public class InventoryTest
    {
        [TestMethod]
        public void Create()
        {
            Program.Main(new string[] { "create Book01 10.50 13.79",
                                        "create Food01 1.47 3.98",
                                        "create Med01 30.63 34.29",
                                        "create Tab01 57.00 84.98"});
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
        [TestMethod]
        public void UpdateBuy()
        {
            Program.Main(new string[] { "create Tab01 57.00 84.98", 
                                        "updateBuy Tab01 100" });
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
        [TestMethod]
        public void UpdateSell()
        {
            Program.Main(new string[] { "create Tab01 57.00 84.98", 
                                        "updateBuy Tab01 100",
                                        "updateSell Tab01 2"});
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
        [TestMethod]
        public void Delete()
        {
            Program.Main(new string[] { "create Book01 10.50 13.79", 
                                        "updateBuy Book01 100",
                                        "delete Book01"});
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
        [TestMethod]
        public void UpdateSellandDelete()
        {
            Program.Main(new string[] { "create Tab01 57.00 84.98", 
                                        "updateBuy Tab01 100",
                                        "updateSell Tab01 2",
                                        "create Book01 10.50 13.79", 
                                        "updateBuy Book01 100",
                                        "delete Book01"});
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
        [TestMethod]
        public void UpdateSellingPrice()
        {
            Program.Main(new string[] { "create Tab01 57.00 84.98", 
                                        "updateBuy Tab01 100",
                                        "updateSell Tab01 2",
                                        "create Book01 10.50 13.79", 
                                        "updateBuy Book01 100",
                                        "updateSellPrice Tab01 80.00",
                                        "updateSell Tab01 2"});
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
        }
    }
}
